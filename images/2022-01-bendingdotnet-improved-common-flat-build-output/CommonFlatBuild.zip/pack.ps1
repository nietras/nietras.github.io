#!/usr/local/bin/powershell
dotnet pack -c Release