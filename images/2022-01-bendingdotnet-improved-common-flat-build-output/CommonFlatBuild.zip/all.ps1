#!/usr/local/bin/powershell
./build.ps1
./pack.ps1
./publish.ps1