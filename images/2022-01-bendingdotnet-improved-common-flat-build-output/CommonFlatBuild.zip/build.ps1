#!/usr/local/bin/powershell
dotnet build -c Debug /m /verbosity:minimal /nologo
dotnet build -c Release /m /verbosity:minimal /nologo