﻿namespace CommonFlatBuild;

public class Class1
{
    public void Test()
    {
        // Comment
    }
}
