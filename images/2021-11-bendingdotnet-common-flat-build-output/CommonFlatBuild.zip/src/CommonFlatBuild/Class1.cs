﻿namespace CommonFlatBuild;

public class Class1
{

}
